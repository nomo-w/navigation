$(function() {
    $.ajax({
        type: "GET",
        contentType: "application/json;charset=UTF-8",
        url: "/api/get_config?t=simple",
        //data: JSON.stringify(list),
        success: function(result) {
            result = JSON.parse(result);
            var data = result.data;
            if (data.a == 1) {
                $("#icons").prepend('<li><a href="/nav/main"><img src="img/icon.png"><span>亿彩</span></a></li>');
                $("#game dd a").eq(0).attr("href", "/nav/main").html("亿彩");
                $("#cai dd a").eq(0).attr("href", "/nav/main").html("亿彩")
            }
            if (data.b == 1) {
                $(".logo img").attr("src", "img/yc.png");
                $(".addBox a").attr("href", "/nav/main");
                $(".addBox img").attr("src", "img/add.jpg");
                $(".links").prepend('<li><a href="/nav/main">亿彩</a></li>')
            }
        },
        //请求失败，包含具体的错误信息
        error: function(e) {
            console.log(e.status);
            console.log(e.responseText);
        }
    });
})